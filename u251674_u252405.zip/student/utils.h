#ifndef _UTILS_H_
#define _UTILS_H_

#include "common.h"

int read_int(); 

void read_filename(char* filename); 

int max(int a, int b); 

#endif